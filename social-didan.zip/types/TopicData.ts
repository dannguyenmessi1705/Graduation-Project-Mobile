export interface TopicData {
  id: string;
  name: string;
  description: string;
  totalPosts: number;
  totalComments: number;
}
